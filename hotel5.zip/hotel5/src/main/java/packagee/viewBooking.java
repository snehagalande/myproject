package packagee;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.mysql.cj.jdbc.Driver;

/**
 * Servlet implementation class viewBooking
 */
@WebServlet("/viewBook") 
public class viewBooking extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public viewBooking() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");

		String url = "jdbc:mysql://localhost:3306/hotel_management";
		String user = "root";
		String password = "sneha@123";

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			// Load and register JDBC driver
			Driver d = new com.mysql.cj.jdbc.Driver();
			DriverManager.registerDriver(d);

			// Establish connection to the database
			conn = DriverManager.getConnection(url, user, password);

			// Prepare the SQL query
			String query = "SELECT * FROM rooms_books";
			ps = conn.prepareStatement(query);

			// Execute the query and retrieve the result set
			rs = ps.executeQuery();

			// Create a list to store booking data
			List<roombook> roomBookings = new ArrayList<>();

			// Loop through the result set and add each booking to the list
			while (rs.next()) {
				roombook booking = new roombook();
				booking.setId(rs.getInt("id"));
				booking.setName(rs.getString("name"));
				booking.setCategory(rs.getString("category"));
				booking.setPrice(rs.getInt("price"));
				booking.setPhone(rs.getInt("phone"));
				roomBookings.add(booking);
			}

			// Set the list as a request attribute
			request.setAttribute("viewlist", roomBookings);

			// Forward the request to the JSP
			// Update the path below based on where your JSP file is located
			request.getRequestDispatcher("ViewRooms.jsp").forward(request, response);

		} catch (SQLException e) {
			e.printStackTrace();
			response.getWriter().println("Error: " + e.getMessage());
		} finally {
			// Close the resources
			if (rs != null) try { rs.close(); } catch (SQLException ignore) {}
			if (ps != null) try { ps.close(); } catch (SQLException ignore) {}
			if (conn != null) try { conn.close(); } catch (SQLException ignore) {}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
