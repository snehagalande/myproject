package packagee;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.mysql.cj.jdbc.Driver;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class RoomServlet
 */

@WebServlet("/RoomBookingServlet") 
public class RoomServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RoomServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		 String Name = request.getParameter("name");
	     String category = request.getParameter("category");
	   	 int price = Integer.parseInt(request.getParameter("price"));
	   	 int phone = Integer.parseInt(request.getParameter("phone"));

//	   	 int checkIn = Integer.parseInt(request.getParameter("checkIn"));
//	   	 int checkOut = Integer.parseInt(request.getParameter("checkOut"));
			
	   	 try {
//	            Class.forName("com.mysql.cj.jdbc.Driver");
	        	Driver D=new com.mysql.cj.jdbc.Driver();
	        	DriverManager.registerDriver(D);
	            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management", "root", "sneha@123");
	            PreparedStatement ps = conn.prepareStatement("insert into rooms_books(name,category,price,phone)values(?,?,?,?)");
	            ps.setString(1,Name);
				ps.setString(2,category);
				ps.setInt(3,price);
				ps.setInt(4, phone);
//				ps.setInt(4,checkIn);
//				ps.setInt(5,checkOut);
				
				ps.executeUpdate();
				
		   }catch(Exception e) {
			   out.print(e);
		   }
	   	 
	        
	}

}
