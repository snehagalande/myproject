package packagee;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class LoginServlett
 */
@WebServlet("/login")
public class LoginServlett extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlett() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		 String email = request.getParameter("email");
	        String password = request.getParameter("pass");

	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management", "root", "sneha@123");
	            PreparedStatement ps = conn.prepareStatement("SELECT * FROM userss WHERE email = ? AND password = ?");
	            ps.setString(1, email);
	            ps.setString(2, password);
	            ResultSet rs = ps.executeQuery();

	            if (rs.next()) {
	                // User authenticated successfully
	            	//response.sendRedirect("selectvechical.jsp"); // Redirect to a welcome page
	            	//out.print("print");
                    response.sendRedirect("dashboard.jsp");
	            } else {
	                // User not found, redirect to signup page with message
	                response.sendRedirect("login.jsp?error=Invalid credentials, please sign up.");
	            	//response.sendRedirect("please sign up");
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}

}
